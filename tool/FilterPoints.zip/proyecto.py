#-------------------------------------------------------------------------------
# Nombre:       Proyecto Final
# Asignatura:   T?cnicas de Documentaci?n Patrimonial ARquitect?nica
# Autores:        Diana Alonso
#
# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# -* coding: utf-8
# 0.0 Bibliotecas empleadas
import sys
import math
from os import path
from PyQt4 import QtGui, uic
from PyQt4.QtGui import QFileDialog, QMessageBox, QPixmap
import image_rc
from PyQt4.QtCore import QRect
from PyQt4.QtGui import (QApplication, QGroupBox, QMainWindow, QLabel,
                         QLineEdit, QWidget, QSlider)
import numpy as np
from matplotlib.mlab import griddata
from mpl_toolkits.mplot3d.axes3d import *
from matplotlib import cm
import matplotlib.pyplot as plt
from collections import defaultdict
from collections import namedtuple
from math import sqrt
import random
# 1.0 Cargo el formulario (XML --> PY)
form_class = uic.loadUiType("proyectoFinal.ui")[0]

# 2.0 Dialog Class
class MyDialogClass(QtGui.QDialog, form_class):

    # 2.1 Inicio de la funcion
    def __init__(self, parent = None):
        QtGui.QDialog.__init__(self,parent)
        self.setupUi(self)

        # 2.1.1 Titulo
        self.setWindowTitle("Filtrado de Nube de Puntos")

        # 2.1.2 Carpeta donde se guardaran los shp
        self.export_folder = '.'

        # 3.0 Eventos + Funciones
            # Cargamos el shapefile
        self.btn_cargar_xyz.clicked.connect(self.cargarXYZ)
            # Seleccionamos carpeta de salida
        self.btn_elegir_carpeta.clicked.connect(self.elegirCarpeta)
            # Botones aceptar y salir
        self.btn_aceptar.clicked.connect(self.aceptar)
        self.btn_cancelar.clicked.connect(self.cancelar)
        self.set_next_rgb_value = True
        self.set_next_hex_value = True

        # Aniado rangos al item de rangos de rgb
        colores_secundarios = ["Amarillo", "Magenta", "Cian", "Verde"]
        self.combo_rangos.addItems(colores_secundarios)


        for slider in (self.red_slider, self.green_slider,
                       self.blue_slider):
            # Establecer valor m?nimo y m?ximo (0 - 255).
            slider.setMinimum(0)
            slider.setMaximum(255)
            # Conectar la se?al que indica si cambia el valor.
            slider.valueChanged.connect(self.slider_value_changed)

        # Establecer el valor inicial (negro).
        self.slider_value_changed(0)


        # Establecer el valor inicial (negro).
        self.slider_value_changed(0)

        # RGB y HEX
        self.rgb_edit.textEdited.connect(self.rgb_edit_changed)
        self.hex_edit.textEdited.connect(self.hex_edit_changed)

        # Activar y desactivar botones
        self.check_filtro_rangos.clicked.connect(self.activar_filtro_rangos)
        self.check_filtro_rgb_esp.clicked.connect(self.activar_filtro_rgb_esp)
        self.check_filtro_el.clicked.connect(self.activar_filtro_elevacion)
        self.check_filtro_tol.clicked.connect(self.activar_filtro_tol)


    # Funciones de activacion
    def activar_filtro_tol(self):
        if self.check_filtro_tol.isChecked():
            self.spin_tol.setEnabled(True)
            self.btn_aceptar.setEnabled(True)
        else:
            self.spin_tol.setEnabled(False)

    def activar_filtro_rangos(self):
        if self.check_filtro_rangos.isChecked():
            self.combo_rangos.setEnabled(True)
            self.btn_aceptar.setEnabled(True)
        else:
            self.combo_rangos.setEnabled(False)

    def activar_filtro_rgb_esp(self):
        if self.check_filtro_rgb_esp.isChecked():
            self.red_slider.setEnabled(True)
            self.green_slider.setEnabled(True)
            self.blue_slider.setEnabled(True)
            self.rgb_edit.setEnabled(True)
            self.hex_edit.setEnabled(True)
            self.btn_aceptar.setEnabled(True)
        else:
            self.red_slider.setEnabled(False)
            self.green_slider.setEnabled(False)
            self.blue_slider.setEnabled(False)
            self.rgb_edit.setEnabled(False)
            self.hex_edit.setEnabled(False)

    def activar_filtro_elevacion(self):
        if self.check_filtro_el.isChecked():
            self.line_minz.setEnabled(True)
            self.line_maxz.setEnabled(True)
            self.btn_aceptar.setEnabled(True)
        else:
            self.line_minz.setEnabled(False)
            self.line_maxz.setEnabled(False)

    # 2.2 Desarrollo de     ######## FUNCIONES ##########
    def rgb_to_hex(self, rgb):
        """
        Convertir un color RGB a hexadecimal.
        """
        return "%02x%02x%02x" % rgb

    def hex_to_rgb(self, color):
        """
        Convertir un color hexadecimal a RGB.
        """
        return tuple(int(color[i:i + 2], 16) for i in range(0, 6, 2))

    def update_sliders(self, rgb):
        """
        Actualizar los deslizadores.
        """
        self.red_slider.setValue(rgb[0])
        self.green_slider.setValue(rgb[1])
        self.blue_slider.setValue(rgb[2])

    def rgb_edit_changed(self, rgb):
        """
        Actualizar los deslizadores cuando el usuario
        modifique manualmente la caja de texto RGB.
        """
        try:
            rgb = tuple(int(i) for i in rgb.split(","))
        except ValueError:
            pass
        else:
            self.set_next_rgb_value = False
            self.update_sliders(rgb)

    def hex_edit_changed(self, color):
        """
        Actualizar los deslizadores cuando el usuario
        modifique manualmente la caja de texto hexadecimal.
        """
        self.set_next_hex_value = False

        if len(color) == 6:
            try:
                rgb = self.hex_to_rgb(str(color))
            except ValueError:
                pass
            else:
                self.update_sliders(rgb)

    def slider_value_changed(self, value):
        """
        Actualizar CSS (hoja de estilo) en el widget
        que visualiza el color.
        """
        # Nuevo valor.
        new_rgb_value = (
                self.red_slider.value(),
                self.green_slider.value(),
                self.blue_slider.value()
            )

        # Actualizar CSS.
        self.color_widget.setStyleSheet(
            "border: 1px solid black;"
            "background-color: rgb(%d, %d, %d)" %
            (
                self.red_slider.value(),
                self.green_slider.value(),
                self.blue_slider.value()
            )
        )

        # Insertar nuevos textos.
        # Remover "(" y ")".
        if self.set_next_rgb_value:
            self.rgb_edit.setText(str(new_rgb_value)[1:-1])
        else:
            self.set_next_rgb_value = True

        # Convertir a hexadecimal.
        if self.set_next_hex_value:
            self.hex_edit.setText(self.rgb_to_hex(new_rgb_value))
        else:
            self.set_next_hex_value = True


    # NombreFuncion: aceptar
    # Descripcion: se realiza un algoritmo u otro en funcion del check seleccionado y el spin marcado
    def aceptar(self):
        # Mostramos un error si no se ha selecionado carpeta de salida
        if foldername == "":
            QMessageBox.information(None, u'ERROR!', u'No se ha seleccionado carpeta de salida')
            return


        # FILTRADO POR ALTURAS

        if self.check_filtro_el.isChecked():
            nombre = '\sfiltro_ele.xyz'
            # Leo el valor de zmax
            minz = (self.line_minz.text())
            print minz
            maxz = (self.line_maxz.text())
            print maxz
            resultados = [minz, maxz]
            tipo ='Z'
            self.ficheroSalida (resultados , nombre, tipo)
            QMessageBox.information(None, u'BIEN!', u'Filtro de elevacion generado')
            return


        if self.check_filtro_tol.isChecked():
            nombre = '\sfiltro_tol.xyz'
            # Creo cluster
            Point = namedtuple('Point', ('coords', 'n', 'ct'))
            Cluster = namedtuple('Cluster', ('points', 'center', 'n'))
            # Leo el spin con la tolerancia'
            resultados = float(self.spin_tol.value())
            lista = self.filtro_tol(resultados)
            salida =  foldername + nombre
            fich_sal = open(salida, 'w')
            for ele in lista:
                x = str(ele[0])
                y = str(ele[1])
                z = str(ele[2])
                cad = x + ',' + y + ',' +  z + '\n'
                fich_sal.write(cad)
            fich_sal.close()
            QMessageBox.information(None, u'BIEN!', u'Filtro de tolerancia generado')
            return

        # Realizar filtrado por RGB especifico
        if self.check_filtro_rgb_esp.isChecked():
            nombre = '\sfiltro_rgb_esp.xyz'

            # Llama a la funci?n filtrado_por_rgb
            print 'Haciendo filtrado por RGB...'
            cloud = {}
            # Busco un color determinado dentro de todo el archivo
             # Leo el rgb del slider
            vred = self.red_slider.value()
            vgreen = self.green_slider.value()
            vblue = self.blue_slider.value()
            print 'R', vred, ' G: ', vgreen, ' B: ', vblue

            cloud = {}

            # Creo cadena para buscar en el archivo
            cl = str(vred) + '-' + str(vgreen)+'-' + str(vblue)
            i = 0
            clases = self.administrarClases(filepath)
            if cl in clases:
                print i
                cloud[cl] = {'x':[],'y':[],'z':[]}
                y = []
                z = []
                clr = cl.split('-')
                r = clr[0]
                g = clr[1]
                b = clr[2]
                #print r,g,b
                print 'Esta ese color'
                tipo = 'RGB'
                resultados = [r,g,b]
                self.ficheroSalida (resultados , nombre, tipo)
                # Eliminamos color del archivo inicial
                QMessageBox.information(None, u'BIEN!', u'Fichero filtrado por RGB generado')
                return
            else:
                print 'No esta ese color'
                QMessageBox.information(None, u'ERROR!', u'Combinacion no disponible')
                return



        if self.check_filtro_rangos.isChecked():
            nombre = '\sfiltro_rangos.xyz'
            tipo = 'RangosRBG'
            rcolor = self.combo_rangos.currentText()
            if rcolor == "Amarillo":
                rmn = 199
                gmn = 156
                bmn = 0
                rmx = 255
                gmx= 255
                bmx = 79
                resultados = [rmn, gmn, bmn, rmx, gmx, bmx]
            if rcolor == "Magenta":
                rmn = 128
                gmn = 0
                bmn = 128
                rmx = 255
                gmx= 0
                bmx = 255
                resultados = [rmn, gmn, bmn, rmx, gmx, bmx]
            if rcolor == "Cian":
                rmn = 0
                gmn = 128
                bmn = 128
                rmx = 224
                gmx= 255
                bmx = 255
                resultados = [rmn, gmn, bmn, rmx, gmx, bmx]

            if rcolor == "Verde":
                rmn = 0
                gmn = 63
                bmn = 0
                rmx = 207
                gmx= 255
                bmx = 185
                resultados = [rmn, gmn, bmn, rmx, gmx, bmx]

            self.ficheroSalida (resultados , nombre, tipo)
            QMessageBox.information(None, u'BIEN!', u'Fichero filtrado por rangos RGB generado')
            return

    def ficheroSalida (self, resultados , nombre, tipo):
        salida =  foldername + nombre
        fich_sal = open(salida, 'w')
        fich_ent = open(filepath, 'Ur')
        for line in fich_ent:
            linea = line.split(',')
            x, y, z =  float(linea[0]), float(linea[1]) , float(linea[2])
            r, g, b =  int(linea[3]), int(linea[4]) , int(linea[5].rstrip('\n') )
            if tipo == 'RGB':
                a = resultados[0]
                b = resultados[1]
                c = resultados[2]
                if a != r and b != g and c != b:
                    cad = str(x) + ',' + str(y) + ',' + str(z) + ','  + str(r) + ','  + str(g) + ','  + str(b) + '\n'
                    fich_sal.write(cad)
            if tipo == 'Z':
                zmin = float(resultados[0])
                zmax = float(resultados[1])
                if z > zmin and z < zmax:
                    cad = str(x) + ',' + str(y) + ',' + str(z) + ','  + str(r) + ','  + str(g) + ','  + str(b) + '\n'
                    fich_sal.write(cad)

            if tipo == 'RangosRGB':
                if r >= int(resultados[0]) and r <= int(resultados[3]) and g >= int(resultados[1]) and g >= int(resultados[4]) and b >= int(resultados[2])  and b <= int(resultados[5]) :
                    cad = str(x) + ',' + str(y) + ',' + str(z) + ','  + str(r) + ','  + str(g) + ','  + str(b) + '\n'
                    fich_sal.write(cad)


        fich_ent.close()
        fich_sal.close()
        print 'FICHERO GENERADO'

##    def rangosRGB(self,rgmMin, rgbMax):

    def filtro_tol(self, Tol):
        COORD = [] # Lista vacia para almacenar las coordenadas XYZ de cada punto
        f_ent = open(filepath, 'Ur') # Apertura del archivo csv
        for line in f_ent: # Bucle para leer linea a linea el archivo.
            linea = line.split(',')
            pto = [float(linea[0]), float(linea[1]), float(linea[2])] # Extraccion de las coordenadas y almacenadas en la variable pto.
            #print pto
            COORD.append(pto) # Anexo la variable pto a la lista vacia de coordenadas.
        f_ent.close() # Cierre de lectura del archivo csv
        lista_fil = [] # Creo una lista vacia en donde almacenare los ptos que cumplan con la tolerancia o la condici?n.
        i = 0
        for i in range(len(COORD)-1): # Le pido que recorra la lista de puntos la longuitud de la lista -1
            A = COORD[i] # almaceno en la variable A las coordendas del punto 1
            B = COORD[i+1] # almaceno en la variable B las coordendas del punto 2
            X1 = A[0] # almaceno en la variable X1 las coordenda X del punto 1
            X2 = B[0] # almaceno en la variable X2 las coordenda X del punto 2
            Y1 = A[1] # almaceno en la variable Y1 las coordenda Y del punto 1
            Y2 = B[1] # almaceno en la variable Y2 las coordenda Y del punto 2
            distAB = ((X1 - X2)**2 + (Y1 - Y2)**2)**0.5 # Calculo la distancia entre los puntos A y B
            #print distAB
            if distAB < Tol: # Condiciono que la distancia calculada no sobrepase la tolerancia deseada
                pto = A[0], A[1], A[2] # Si se cumple la condicion, almaceno los valores XYZ del punto en una variable
                lista_fil.append(pto) # Y almaceno dicha variable en la lista filter
        return lista_fil

    def filtrado_por_rgb(self, clases, filepath):

        # Leo el rgb del slider
        vred = self.red_slider.value()
        vgreen = self.red_slider.value()
        vblue = self.rgb_edit.value()
        print 'R', vred, ' G: ', vgreen, ' B: ', vblue

        cloud = {}

        # Creo cadena para buscar en el archivo
        cl = str(vred) + '-' + str(vgreen)+'-' + str(vblue)
        i = 0

        if cl in clases:
            print i
            cloud[cl] = {'x':[],'y':[],'z':[]}
            y = []
            z = []
            clr = cl.split('-')
            r = clr[0]
            g = clr[1]
            b = clr[2]
            #print r,g,b

            for pts in range(len(clases)):
                for line in filepath:
                    linea = line.split(',')
                    #print linea[3]
                    if linea[3] == r and linea[4] == g and linea[5].rstrip('\n') == b:
                        cloud[cl]['x'].append(float(linea[0]))
                        cloud[cl]['y'].append(float(linea[1]))
                        cloud[cl]['z'].append(float(linea[2]))
                        # Trasformo a hexagesimal porque matplot no acepta rgb
                        c = rgb2hex(int(r),int(g), int(b))
                        print c
                # Graficar todos los puntos que son de eso color
            fig = plt.figure()
            ax = fig.add_subplot(111, projection='3d')
            for pto in range(len(cloud[cl]['x'])):
                ax.scatter(cloud[cl]['x'], cloud[cl]['y'], cloud[cl]['z'], c=c, marker='.')
                        #y.append(float(linea[1]))
                        #z.append(float(linea[2]))


        print cloud
        plt.show()

    # NombreFuncion: cancel
    # Descripcion: cierra el dialogo y sale
    def cancelar(self):
        self.close()


    # NombreFuncion: elegirCarpeta
    # Descripcion: cuando se pulsa el boton permite elegir la carpeta de salida
    def elegirCarpeta(self):
        global foldername
        foldername = str(QFileDialog.getExistingDirectory(self, "Select Directory"))
        #print foldername
        if not foldername : return

        self.export_folder = foldername
        self.label_selected_folder.setText(self.export_folder)
        #print self.export_folder

    # NombreFuncion: cargarXYZ
    # Descripcion: permite carhar un archivo vectorial y de lineas
    def cargarXYZ(self):

        foldername =""
        global foldername

        # Dialogo nativo para elegir fichero
        dlg = QFileDialog()
        dlg.setFileMode(QFileDialog.ExistingFile)

        # Indico que me muestre solo los archivos de extension .xyz
        dlg.setFilter("Fichero .csv (*.csv)")

        if dlg.exec_():
            # Obtenemos la ruta del archivo
            global filepath
            filepath = map(str, list(dlg.selectedFiles()))[0]
            self.label_shp_path.setText(filepath)


        # Activar elementos
               # Se activan los componentes desactivados de mcmastery y douglas
        self.check_filtro_rangos.setEnabled(True)
        self.check_filtro_rgb_esp.setEnabled(True)
        self.check_filtro_el.setEnabled(True)
        # Se cuentan las clases
        n_clases = len(self.administrarClases(filepath))
        self.label_clases.setText(str(n_clases))
        zmin, zmax = self.calcularZetas(filepath)
        self.label_zmin.setText(str(zmin))
        self.label_zmax.setText(str(zmax))
        self.check_filtro_tol.setEnabled(True)

        # Nombre: ibtenerXYZRGB
        # Descripci?n: devuelve dos cadenas, una con rgb y la otra con xyz
    def obtenerXYZRGB(self, dir_fichero):
        cad_rgb = []
        print dir_fichero
        file = open(dir_fichero, 'Ur')
        for line in file:
            linea = line.split(',')
            color = linea[3] +'-'+ linea[4] + '-' + linea[5].rstrip('\n')
            cad_rgb.append(color)
        #print cad_rgb
        file.close()
        file = open(dir_fichero, 'Ur')
        cad_xyz = []
        for line in file:
            linea = line.split(',')
            coord = linea[0] +'-'+ linea[1] + '-' + linea[2]
            cad_xyz.append(coord)
        file.close()
        #print cad_xyz
        return cad_rgb, cad_xyz

    def calcularZetas(self, dir_fichero):
        cad_rgb, cad_xyz = self.obtenerXYZRGB( dir_fichero)
        cad = cad_xyz[0].split("-")
        zmin = float(cad[2])
        zmax = float(cad[2])
        for elemento in cad_xyz:
            cad = elemento.split("-")
            z = float(cad[2])
            if z < zmin:
                zmin = z
            if z > zmax:
                zmax = z
        print 'Zmin:', zmin
        print 'Zmax:', zmax
        return zmin, zmax


    def administrarClases(self, dir_fichero):
        cad_rgb, cad_xyz = self.obtenerXYZRGB( dir_fichero)
        aux = defaultdict(list)
        for index, item in enumerate(cad_rgb):
            aux[item].append(index)
        result = {item: indexs for item, indexs in aux.items() if len(indexs) > 1}
        #print result
        #print(result['47-58-56'])

        clases = []
        for clase in result:
           clases.append(clase)
        print len(clases)
        #Variedades de RGB
        return clases

    def rgb2hex(self,r, g, b):
        return '#{:02x}{:02x}{:02x}'.format(r, g, b)





app = QtGui.QApplication(sys.argv)
myDialog = MyDialogClass(None)
myDialog.show()
app.exec_()